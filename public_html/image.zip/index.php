<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="vendor/style.css">
        <link rel="stylesheet" type="text/css" href="vendor/responsive.css">
         <!--FONT AWESOME-->
        <script src="https://kit.fontawesome.com/597dd717a9.js" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="container">
            <header>
                <nav>
                    <div class="logo">
                        <img src="image/logo.png" alt="logo">
                    </div>
                    <div class="navigation-menu">
                        <div class="menu">
                            <ul>
                                <li class="active"><a href="#"><i class="fas fa-home"></i>Home</a></li>
                                <li><a href="#"><i class="fas fa-clone"></i>Services</a>
                                        <div class=" menu-2 sub-menu2">
                                                <ul>
                                                    <li><a href="#">web designing</a></li>
                                                    <li><a href="#">marketing</a></li>
                                                    <li><a href="#">mobile app</a></li>
                                                </ul>
                                            </div>
                                </li>
                                <li><a href="#"><i class="fas fa-images"></i>gallery</a></li>
                                <li><a href="#"><i class="fas fa-user"></i>About us</a>
                                    <div class="sub-menu1">
                                        <ul>
                                            <li><a href="#">misson</a></li>
                                            <li><a href="#">visson</a></li>
                                            <li><a href="#">team</a></li>
                                        </ul>
                                    </div>
                                </li>
                                <li><a href="#"><i class="fas fa-phone-alt"></i>contact us</a></li>
                            </ul>
                        </div>
                        <div class="mobile-menu">
                            <a href="#" class="humberger" onclick="openNav()">&#9776;</a>
                            
                        </div>
                        <div class="sidenav" id="opensidenav">
                            <ul>
                                 <a href="javascript:void(0)" class="close" onclick="closeNav()">&times;</a>
                                <li><a href="#"><i class="fas fa-home"></i>Home</a></li>
                                <li><a href="#"><i class="fas fa-images"></i>gallery</a></li>
                                <li><a href="#"><i class="fas fa-user"></i>About us</a></li>
                                 <li><a href="#"><i class="fas fa-phone-alt"></i>contact us</a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <div class="hero-text-box">
                        <h1>Hi there! We are the new kids on the block 
                            and we build awesome websites and mobile apps.</h1>
                             <a href="#" class="btn btn-hero">work with us!</a>
                    </div>
            </header>
            <div class="close-btn">
                <a href="javascript:void(0)" class="close" onclick="closeNav()">&times;</a>
            </div>
            
        </div>
        <script>
            function openNav(){
                document.getElementById('opensidenav').style.width='20rem';
            }
            function closeNav(){
                document.getElementById('opensidenav').style.width='0rem';
            }
        </script>
    </body>
</html>
